package com.openfabric.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.openfabric.test.OpenFabricHomeTest;

public class OpenFabricHomePage
{
	WebDriver driver;
	public OpenFabricHomePage(WebDriver driver) {
		
	}

	public String launchHomeUrl(String url)
	{
		driver.navigate().to("https://openfabric.dev/login");
		return url;
	}
	
	public String getWelcomeTitle(String title)
	{
	title = driver.findElement(By.xpath("//header[@class='login__header form__box-header']/h3")).getText();
		return title;
	}
	
	public void clickRegisterLink()
	{
		driver.findElement(By.xpath("//div[@class='form__box-bottom']//p/a")).click();
	}
}