package com.openfabric.test;

import org.openqa.selenium.WebDriver;

import org.testng.Assert;

import com.openfabric.config.TestBase;
import com.openfabric.pages.OpenFabricHomePage;

public class OpenFabricHomeTest extends TestBase
{
	public String url,title;
	WebDriver driver;
	OpenFabricHomePage ofHomePageObj;
	
	public OpenFabricHomeTest()
	{

	super();
	ofHomePageObj = new OpenFabricHomePage(driver);
	
	String homeUrl=ofHomePageObj.launchHomeUrl(url);
	String welcomeTitle=ofHomePageObj.getWelcomeTitle(title);
	ofHomePageObj.clickRegisterLink();
	
	}
	
}