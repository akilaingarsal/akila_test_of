package com.openfabric.config;
 
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;


public class TestBase
{
	public static WebDriver driver;
	
	public TestBase()
	{
		loadBrowser();
	}
	
	public void loadBrowser()
	{
		try
		{
			if (driver==null || driver.toString().contains("null"))
			{
			   WebDriverManager.chromedriver().setup();
			   driver= new ChromeDriver();
			   driver.manage().window().maximize();
			   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			}
			else
			{
				System.out.println("browser loaded");
			}
			
		}catch (Exception excep)
		{
			System.out.println("exception");
		}
	}
}
 